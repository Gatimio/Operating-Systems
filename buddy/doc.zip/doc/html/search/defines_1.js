var searchData=
[
  ['buddy_5faddr_125',['BUDDY_ADDR',['../buddy_8c.html#aae7263f0e40a1e0dfefa6f53652a4a05',1,'buddy.c']]]
];
