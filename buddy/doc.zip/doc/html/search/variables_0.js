var searchData=
[
  ['free_5farea_102',['free_area',['../buddy_8c.html#a6d390a89d1f6c149cef6284d2c0351df',1,'buddy.c']]]
];
